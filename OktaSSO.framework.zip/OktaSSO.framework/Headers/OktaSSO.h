//
//  OktaSSO.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIApplication.h>

#import "OKConstants.h"
#import "OKSSOResponse.h"
#import "Singleton.h"


@interface OktaSSO : Singleton

@property (nonatomic) SecKeyRef privateKey;
@property (nonatomic) SecKeyRef publicKey;

-(BOOL) sendRequestForApp:(NSString *) appName forTokenType:(OKTokenType) tokenType;
-(OKSSOResponse*) handleSSOResponse:(NSURL *) responseURL;
-(BOOL) isOktaSSOResponse:(NSURL *) url;


@end
