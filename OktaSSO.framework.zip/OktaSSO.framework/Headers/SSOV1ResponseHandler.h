//
//  SSOV1ResponseHandler.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SSORespondeHandler.h"
#import "Singleton.h"

@interface SSOV1ResponseHandler : Singleton<SSORespondeHandler>

@end
