//
//  OKOAuth2Response.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OKOAuth2Response : NSObject

    // tracker fields
    @property BOOL success;
    
    // fields to capture error
    @property(copy) NSString *error;
    @property(copy) NSString *errorDescription;
    @property(copy) NSString *errorURI;
    
    // fields to capture access token
    @property(copy) NSString *accessToken;
    @property(copy) NSString *tokenType;
    @property NSNumber *expiresIn;
    @property(copy) NSString *refreshToken;

    // common fields
    @property(copy) NSString *state;
    
    @property(readonly) NSDictionary *responseDictionary;


+(OKOAuth2Response*) initWithDictionary:(NSDictionary*) responseDictionary;

-(NSDictionary*) asDictionary;

@end
