//
//  OKConstants.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#ifndef OktaSSOSDK_OKConstants_h
#define OktaSSOSDK_OKConstants_h

typedef enum {
    OKTokenTypeOAUTH1 = (1UL << 0),
    OKTokenTypeOAUTH2 = (1UL << 1),
    OKTokenTypeCOOKIES = (1UL << 2)
} OKTokenType;

#define OKTA_SSO_SCHEME @"OktaSSO"


#endif
