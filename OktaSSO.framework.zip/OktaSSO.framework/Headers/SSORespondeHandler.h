//
//  SSORespondeHandler.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OKSSOResponse.h"
#import "OktaSSO.h"

@protocol SSORespondeHandler <NSObject>

-(OKSSOResponse*) handleSSOResponse:(NSURL*) url oktaSSO:(OktaSSO*) oktaSSO;

@end
