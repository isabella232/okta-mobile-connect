//
//  OKSSOResponse.h
//  OktaSSO
//
//  Created by Vinoth Jayaraman on 6/3/13.
//  Copyright (c) 2013 Okta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OKConstants.h"
#import "OKOAuth2Response.h"

@interface OKSSOResponse : NSObject

#pragma mark properties
@property NSString *requestURL;
@property OKTokenType tokenType;

@property NSString *responseText;
@property (nonatomic) BOOL isError;

#pragma mark methods

-(OKOAuth2Response*) responseAsOAuth2;
-(NSString *) responseAsString;

@end
